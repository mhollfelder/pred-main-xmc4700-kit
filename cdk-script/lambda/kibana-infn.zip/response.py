import requests
import json


def is_complete(event, context):
    print(event)
    return post_response(event)


def post_response(event):
    print(event)
    response_data = {}
    print(event)
    response_data['StackId'] = event.get('StackId')
    response_data['RequestId'] = event.get('RequestId')
    response_data['LogicalResourceId'] = event.get('LogicalResourceId')
    response_data['PhysicalResourceId'] = event.get('PhysicalResourceId')

    response_data['Reason'] = 'More information in CloudWatch'
    response_data['Status'] = 'SUCCESS'
    response_data['Data'] = {}
    json_response = json.dumps(response_data)
    try:
        headers = {
            'content-type': '',
            'content-length': str(len(json_response))
        }
        response = requests.put(event.get('ResponseURL'), data=json_response, headers=headers)
        print(response.content)
    except requests.exceptions.ConnectionError as e:
        print('Connection refused')
        print(e)
    return {'IsComplete': 'true'}
